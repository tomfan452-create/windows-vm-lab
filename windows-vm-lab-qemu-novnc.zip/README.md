# Windows VM Lab — QEMU + noVNC

Segunda parte del proyecto: backend local para controlar máquinas virtuales QEMU y acceder a ellas desde el navegador mediante noVNC.

## Arquitectura

Navegador → noVNC → WebSocket → QEMU VNC
                     ↑
              API Flask → QEMU

## Requisitos

- Linux recomendado (Ubuntu/Debian)
- QEMU
- Python 3
- noVNC
- Una ISO legal de cada Windows que quieras instalar
- CPU con virtualización para buen rendimiento

> GitHub Pages NO ejecuta este servidor. La web de GitHub Pages puede ser el frontend, mientras este servidor se ejecuta en tu PC/servidor.

## Instalación rápida

```bash
sudo apt update
sudo apt install -y qemu-system-x86 qemu-utils python3 python3-pip git
./scripts/setup-novnc.sh
pip3 install -r server/requirements.txt
```

Coloca las ISOs en `isos/` y crea los discos:

```bash
./scripts/create-disks.sh
```

Luego inicia la API:

```bash
python3 server/app.py
```

Abre `http://127.0.0.1:8080`.

## Seguridad

El servidor escucha en localhost por defecto. No lo expongas directamente a Internet sin autenticación, HTTPS y un firewall/VPN.

Las ISOs de Windows y las instalaciones completas NO están incluidas.
