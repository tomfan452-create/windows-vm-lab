#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
if [ ! -d novnc ]; then
  git clone --depth 1 https://github.com/novnc/noVNC.git novnc
fi
echo "noVNC instalado en ./novnc"
echo "Para conectar VNC desde el navegador usa websockify:"
echo "  ./novnc/utils/novnc_proxy --vnc localhost:5900 --listen 6080"
