#!/usr/bin/env bash
set -e
mkdir -p vms
for name in winxp vista win7 win81 win10 win11; do
  if [ ! -f "vms/$name.qcow2" ]; then
    qemu-img create -f qcow2 "vms/$name.qcow2" 32G
  fi
done
echo "Discos creados en ./vms"
