import os, signal, subprocess, time
from flask import Flask, jsonify, send_from_directory, abort
from flask_cors import CORS

BASE=os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
WEB=os.path.join(BASE,"web")
VMS=os.path.join(BASE,"vms")
ISOS=os.path.join(BASE,"isos")

app=Flask(__name__, static_folder=WEB)
CORS(app, resources={r"/api/*":{"origins":"*"}})

VM={
 "winxp":{"name":"Windows XP","disk":"winxp.qcow2","iso":"winxp.iso","machine":"pc","memory":"1024","qemu":"qemu-system-i386"},
 "vista":{"name":"Windows Vista","disk":"vista.qcow2","iso":"vista.iso","machine":"pc","memory":"2048","qemu":"qemu-system-i386"},
 "win7":{"name":"Windows 7","disk":"win7.qcow2","iso":"win7.iso","machine":"pc","memory":"2048","qemu":"qemu-system-x86_64"},
 "win81":{"name":"Windows 8.1","disk":"win81.qcow2","iso":"win81.iso","machine":"pc","memory":"4096","qemu":"qemu-system-x86_64"},
 "win10":{"name":"Windows 10","disk":"win10.qcow2","iso":"win10.iso","machine":"q35","memory":"4096","qemu":"qemu-system-x86_64"},
 "win11":{"name":"Windows 11","disk":"win11.qcow2","iso":"win11.iso","machine":"q35","memory":"6144","qemu":"qemu-system-x86_64"},
}
procs={}

def valid(vm): return vm in VM
def start(vm):
    if not valid(vm): abort(404)
    if vm in procs and procs[vm].poll() is None: return False
    c=VM[vm]
    disk=os.path.join(VMS,c["disk"]); iso=os.path.join(ISOS,c["iso"])
    if not os.path.exists(disk): abort(409, description="Falta el disco "+c["disk"])
    cmd=[c["qemu"],"-name",c["name"],"-machine",c["machine"],
         "-m",c["memory"],"-drive",f"file={disk},format=qcow2,if=virtio",
         "-vnc",f":{5900+list(VM).index(vm)}","-nic","user,model=virtio-net-pci",
         "-usb","-device","usb-tablet"]
    # ISO is attached only when it exists; useful for first installation.
    if os.path.exists(iso):
        cmd += ["-cdrom",iso]
    procs[vm]=subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(.5)
    return True

@app.get("/api/vms")
def list_vms():
    out=[]
    for i,(vm,c) in enumerate(VM.items()):
        p=procs.get(vm)
        out.append({"id":vm,"name":c["name"],"running":bool(p and p.poll() is None),
                    "vnc_port":5900+i})
    return jsonify(out)

@app.post("/api/vms/<vm>/start")
def api_start(vm):
    start(vm); return jsonify({"ok":True,"id":vm})

@app.post("/api/vms/<vm>/stop")
def api_stop(vm):
    p=procs.get(vm)
    if p and p.poll() is None: p.terminate()
    return jsonify({"ok":True,"id":vm})

@app.get("/")
def index(): return send_from_directory(WEB,"index.html")

@app.get("/<path:path>")
def static(path): return send_from_directory(WEB,path)

if __name__=="__main__":
    # Local-only by default.
    app.run(host="127.0.0.1",port=8080)
